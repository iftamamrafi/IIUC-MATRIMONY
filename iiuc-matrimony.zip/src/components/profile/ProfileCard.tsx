import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Heart, ShieldCheck, GraduationCap, MapPin, User as UserIcon } from 'lucide-react';
import { motion } from 'motion/react';

interface ProfileCardProps {
  profile: any;
  onExpressInterest: (id: string) => void;
  onView: (id: string) => void;
}

const ProfileCard: React.FC<ProfileCardProps> = ({ profile, onExpressInterest, onView }) => {
  const isBlurred = profile.photoPrivacy !== 'public';

  return (
    <motion.div
      whileHover={{ y: -5 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="rounded-3xl border-neutral-100 shadow-sm hover:shadow-xl transition-all overflow-hidden bg-white group">
        <div className="relative aspect-[4/5] overflow-hidden bg-neutral-100">
          <img
            src={profile.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.uid}`}
            alt="Profile"
            className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 ${isBlurred ? 'blur-xl' : ''}`}
            referrerPolicy="no-referrer"
          />
          <div className="absolute top-3 left-3 flex gap-2">
            {profile.isVerified && (
              <Badge className="bg-primary hover:bg-primary-dark border-none gap-1 py-1">
                <ShieldCheck className="w-3 h-3" />
                Verified
              </Badge>
            )}
          </div>
          <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/60 to-transparent">
             <h3 className="text-white font-bold text-lg">{profile.userId || 'ID: ' + profile.uid.slice(0, 8)}</h3>
             <div className="flex gap-2 text-white/90 text-xs">
                <span>{profile.age} years</span>
                <span>•</span>
                <span>{profile.gender === 'male' ? 'Brother' : 'Sister'}</span>
             </div>
          </div>
        </div>
        <CardContent className="p-5 space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-neutral-600">
              <GraduationCap className="w-4 h-4 text-primary" />
              <span className="line-clamp-1">{profile.department}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-neutral-600">
              <UserIcon className="w-4 h-4 text-primary" />
              <span>{profile.maritalStatus?.replace('_', ' ') || 'Never Married'}</span>
            </div>
          </div>
          
          <div className="flex gap-2 pt-2">
            <Button 
               variant="outline" 
               className="flex-1 rounded-2xl border-primary text-primary hover:bg-primary/5 text-xs h-10"
               onClick={() => onView(profile.uid)}
            >
              View Profile
            </Button>
            <Button 
              className="flex-1 rounded-2xl bg-primary hover:bg-primary-dark text-xs h-10 gap-2"
              onClick={() => onExpressInterest(profile.uid)}
            >
              <Heart className="w-3 h-3 fill-current" />
              Interest
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProfileCard;
