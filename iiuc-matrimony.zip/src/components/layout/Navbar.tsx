import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { auth } from '../../lib/firebase';
import { Button } from '../ui/button';
import { Heart, Search, MessageCircle, User, LogOut } from 'lucide-react';

const Navbar = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = async () => {
    await auth.signOut();
    navigate('/');
  };

  const navItems = [
    { label: 'Browse', path: '/browse', icon: Search },
    { label: 'Interests', path: '/interests', icon: Heart },
    { label: 'Messages', path: '/messages', icon: MessageCircle },
    { label: 'Profile', path: '/profile', icon: User },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-neutral-100 bg-white/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to={user ? '/dashboard' : '/'} className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-xl">I</span>
          </div>
          <span className="font-heading font-bold text-lg hidden sm:block">IIUC <span className="text-primary">Matrimony</span></span>
        </Link>

        {user ? (
          <>
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-6">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary ${
                    location.pathname === item.path ? 'text-primary' : 'text-neutral-500'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Link>
              ))}
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                className="text-neutral-500 hover:text-red-500 hover:bg-red-50"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>

            {/* Mobile Nav Trigger / Simple Profile */}
            <div className="md:hidden flex items-center gap-4">
               <Link to="/profile" className="w-8 h-8 bg-neutral-100 rounded-full border border-neutral-200 overflow-hidden">
                <img 
                  src={profile?.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} 
                  alt="Avatar" 
                  referrerPolicy="no-referrer"
                />
               </Link>
            </div>
          </>
        ) : (
          <div className="flex items-center gap-4">
             <Link to="/" className="text-sm font-medium text-neutral-500 hover:text-primary">About</Link>
             <Button variant="ghost" className="text-primary font-bold">Contact</Button>
          </div>
        )}
      </div>

      {/* Mobile Bottom Bar */}
      {user && (
        <div className="md:hidden fixed bottom-0 left-0 w-full bg-white border-t border-neutral-100 h-16 flex items-center justify-around px-2 z-50">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center gap-1 transition-colors ${
                location.pathname === item.path ? 'text-primary' : 'text-neutral-400'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
