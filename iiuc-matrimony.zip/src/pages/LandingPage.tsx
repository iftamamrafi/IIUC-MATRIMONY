import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, Shield, CheckCircle2, UserPlus, Users, MessageSquare } from 'lucide-react';
import { Button } from '../components/ui/button';
import { AuthModal } from '../components/auth/AuthModal';

const LandingPage = () => {
  const [authModalOpen, setAuthModalOpen] = useState(false);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden islamic-pattern">
        <div className="container px-4 mx-auto">
          <div className="flex flex-wrap items-center -mx-4">
            <div className="w-full lg:w-1/2 px-4 mb-16 lg:mb-0">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <span className="inline-block py-1 px-3 mb-4 text-xs font-semibold tracking-widest text-primary uppercase bg-primary/10 rounded-full">
                  Exclusively for IIUC
                </span>
                <h1 className="mb-6 text-5xl lg:text-6xl font-bold font-heading text-neutral-900 leading-tight">
                  Find Your Life Partner at <span className="text-primary font-bold">IIUC</span>
                </h1>
                <p className="mb-10 text-lg text-neutral-600 leading-relaxed max-w-lg">
                  A halal, secure, and private platform designed specifically for university students and alumni of International Islamic University Chittagong.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button size="lg" className="rounded-2xl px-8 h-12 bg-primary hover:bg-primary-dark" onClick={() => setAuthModalOpen(true)}>
                    Create Profile
                  </Button>
                  <Button variant="outline" size="lg" className="rounded-2xl px-8 h-12 border-primary text-primary hover:bg-primary/5" onClick={() => setAuthModalOpen(true)}>
                    Login
                  </Button>
                </div>
              </motion.div>
            </div>
            <div className="w-full lg:w-1/2 px-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative"
              >
                <div className="absolute top-0 right-0 -mr-12 -mt-12 w-64 h-64 bg-accent/20 rounded-full blur-3xl opacity-50" />
                <div className="absolute bottom-0 left-0 -ml-12 -mb-12 w-64 h-64 bg-primary/20 rounded-full blur-3xl opacity-50" />
                <img
                  src="/hero-wedding.jpg"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://images.unsplash.com/photo-1542042161784-26ab9e041e89?auto=format&fit=crop&q=80&w=800";
                  }}
                  alt="Wedding Couple"
                  className="relative z-10 w-full rounded-3xl shadow-2xl border-4 border-white object-cover aspect-[4/3]"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-surface">
        <div className="container px-4 mx-auto">
          <div className="max-w-2xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Why IIUC Matrimony?</h2>
            <p className="text-neutral-500">Dedicated to maintaining the highest standards of modesty and trust.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 rounded-3xl bg-background border border-neutral-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 flex items-center justify-center bg-primary/10 rounded-2xl mb-6">
                <CheckCircle2 className="text-primary w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Verified Students</h3>
              <p className="text-neutral-600">Exclusive access for IIUC students and alumni with multi-step verification.</p>
            </div>
            <div className="p-8 rounded-3xl bg-background border border-neutral-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 flex items-center justify-center bg-primary/10 rounded-2xl mb-6">
                <Shield className="text-primary w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Privacy First</h3>
              <p className="text-neutral-600">Complete control over who sees your photos and personal details.</p>
            </div>
            <div className="p-8 rounded-3xl bg-background border border-neutral-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 flex items-center justify-center bg-primary/10 rounded-2xl mb-6">
                <Heart className="text-primary w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Halal Matching</h3>
              <p className="text-neutral-600">A process that respects Islamic values and simplifies meeting potential partners.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-24 bg-background">
        <div className="container px-4 mx-auto text-center">
          <h2 className="text-3xl font-bold mb-16">How It Works</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: UserPlus, title: "Create Profile", step: "01" },
              { icon: Users, title: "Browse Profiles", step: "02" },
              { icon: Heart, title: "Express Interest", step: "03" },
              { icon: MessageSquare, title: "Connect Respectfully", step: "04" },
            ].map((item, idx) => (
              <div key={idx} className="relative">
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-white shadow-md rounded-2xl flex items-center justify-center mb-6 relative z-10 border border-neutral-100">
                    <item.icon className="text-primary w-8 h-8" />
                  </div>
                  <h4 className="text-lg font-bold mb-2">{item.title}</h4>
                  <span className="text-xs uppercase tracking-widest text-primary font-bold">Step {item.step}</span>
                </div>
                {idx < 3 && (
                  <div className="hidden md:block absolute top-8 left-1/2 w-full h-px border-t border-dashed border-primary/30 -z-0" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Islamic Section */}
      <section className="py-24 bg-primary text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl -mr-48 -mt-48" />
        <div className="container px-4 mx-auto relative z-10">
          <div className="max-w-3xl mx-auto text-center italic">
            <h2 className="text-2xl mb-6 text-accent">“And among His Signs is this, that He created for you mates from among yourselves, that ye may dwell in tranquillity with them, and He has put love and mercy between your (hearts)...”</h2>
            <p className="text-sm opacity-80">— Surah Ar-Rum (30:21)</p>
          </div>
        </div>
      </section>

      {/* Auth Modal */}
      <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} />
      
      {/* Footer */}
      <footer className="py-12 bg-surface border-t border-neutral-100">
        <div className="container px-4 mx-auto text-center">
          <img src="https://picsum.photos/seed/iiuc-logo/100/100" alt="IIUC Logo" className="w-14 h-14 mx-auto mb-6 rounded-xl grayscale opacity-50" referrerPolicy="no-referrer" />
          <p className="text-sm text-neutral-500 mb-2">© 2026 IIUC Matrimony. Built with respect for our students.</p>
          <p className="text-xs text-neutral-400 italic">May Allah grant everyone a companion who is the coolness of their eyes.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
