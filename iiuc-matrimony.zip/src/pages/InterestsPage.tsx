import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { collection, query, where, getDocs, updateDoc, doc, addDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, User, Check, X, MessageCircle, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const InterestsPage = () => {
  const { user } = useAuth();
  const [received, setReceived] = useState<any[]>([]);
  const [sent, setSent] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchInterests = async () => {
    if (!user) return;
    setLoading(true);
    try {
      // Received
      const rq = query(collection(db, 'interests'), where('receiverId', '==', user.uid));
      const rSnapshot = await getDocs(rq);
      const rData = await Promise.all(rSnapshot.docs.map(async (d) => {
        const item = { id: d.id, ...d.data() } as any;
        const pDoc = await getDoc(doc(db, 'profiles', item.senderId));
        return { ...item, senderProfile: pDoc.data() };
      }));
      setReceived(rData);

      // Sent
      const sq = query(collection(db, 'interests'), where('senderId', '==', user.uid));
      const sSnapshot = await getDocs(sq);
      const sData = await Promise.all(sSnapshot.docs.map(async (d) => {
        const item = { id: d.id, ...d.data() } as any;
        const pDoc = await getDoc(doc(db, 'profiles', item.receiverId));
        return { ...item, receiverProfile: pDoc.data() };
      }));
      setSent(sData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInterests();
  }, [user]);

  const handleAction = async (interestId: string, status: 'accepted' | 'declined', interest: any) => {
    try {
      await updateDoc(doc(db, 'interests', interestId), { status });
      
      if (status === 'accepted') {
        // Create a conversation
        await addDoc(collection(db, 'conversations'), {
          participants: [interest.senderId, interest.receiverId],
          updatedAt: serverTimestamp(),
          lastMessage: 'Conversation started'
        });
      }
      
      fetchInterests();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 pb-32">
       <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Interests</h1>
        <p className="text-neutral-500">Manage connections and mutual interests.</p>
      </div>

      <Tabs defaultValue="received" className="w-full">
        <TabsList className="bg-neutral-100 rounded-2xl p-1 mb-8">
          <TabsTrigger value="received" className="rounded-xl px-8 data-[state=active]:bg-white data-[state=active]:text-primary">
            Received ({received.length})
          </TabsTrigger>
          <TabsTrigger value="sent" className="rounded-xl px-8 data-[state=active]:bg-white data-[state=active]:text-primary">
            Sent ({sent.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="received">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {received.map((interest) => (
              <Card key={interest.id} className="rounded-3xl border-neutral-100 shadow-sm overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-neutral-100 overflow-hidden">
                       <img src={interest.senderProfile?.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${interest.senderId}`} alt="" referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold">{interest.senderProfile?.userId || 'User'}</h3>
                      <div className="text-xs text-neutral-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {interest.createdAt ? formatDistanceToNow(interest.createdAt.toDate()) + ' ago' : ''}
                      </div>
                    </div>
                    <Badge variant={interest.status === 'pending' ? 'secondary' : (interest.status === 'accepted' ? 'outline' : 'destructive')}>
                      {interest.status}
                    </Badge>
                  </div>
                  
                  {interest.status === 'pending' ? (
                    <div className="flex gap-2">
                       <Button 
                         className="flex-1 rounded-xl bg-primary hover:bg-primary-dark gap-2 h-10"
                         onClick={() => handleAction(interest.id, 'accepted', interest)}
                       >
                         <Check className="w-4 h-4" /> Accept
                       </Button>
                       <Button 
                         variant="outline" 
                         className="flex-1 rounded-xl gap-2 h-10 border-red-100 text-red-500 hover:bg-red-50"
                         onClick={() => handleAction(interest.id, 'declined', interest)}
                       >
                         <X className="w-4 h-4" /> Decline
                       </Button>
                    </div>
                  ) : interest.status === 'accepted' ? (
                    <Button className="w-full rounded-xl bg-neutral-100 text-neutral-900 border-none h-10 gap-2">
                      <MessageCircle className="w-4 h-4" /> Message
                    </Button>
                  ) : null}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="sent">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sent.map((interest) => (
              <Card key={interest.id} className="rounded-3xl border-neutral-100 shadow-sm overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-neutral-100 overflow-hidden">
                       <img src={interest.receiverProfile?.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${interest.receiverId}`} alt="" referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold">{interest.receiverProfile?.userId || 'User'}</h3>
                      <div className="text-xs text-neutral-400">
                        Interested {interest.createdAt ? formatDistanceToNow(interest.createdAt.toDate()) + ' ago' : ''}
                      </div>
                    </div>
                    <Badge className={interest.status === 'accepted' ? 'bg-green-100 text-green-700' : ''}>
                      {interest.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default InterestsPage;
