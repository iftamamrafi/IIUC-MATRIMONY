import React, { useEffect, useState, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy, 
  addDoc, 
  serverTimestamp, 
  doc, 
  getDoc 
} from 'firebase/firestore';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send, Loader2, ArrowLeft, MessageCircle } from 'lucide-react';
import { format } from 'date-fns';

const MessagesPage = () => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeConversation, setActiveConversation] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (!user) return;

    // Fetch conversations where user is a participant
    const q = query(
      collection(db, 'conversations'),
      where('participants', 'array-contains', user.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const convos = await Promise.all(snapshot.docs.map(async (d) => {
        const data = d.data();
        // Get other participant profile
        const otherId = data.participants.find((p: string) => p !== user.uid);
        const pDoc = await getDoc(doc(db, 'profiles', otherId));
        return { id: d.id, ...data, otherProfile: pDoc.data() };
      }));
      setConversations(convos);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (!activeConversation) return;

    const q = query(
      collection(db, 'conversations', activeConversation.id, 'messages'),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setTimeout(scrollToBottom, 100);
    });

    return () => unsubscribe();
  }, [activeConversation]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeConversation || !user) return;

    const text = newMessage;
    setNewMessage('');

    try {
      await addDoc(collection(db, 'conversations', activeConversation.id, 'messages'), {
        senderId: user.uid,
        text,
        createdAt: serverTimestamp()
      });
      // Update last message in conversation
      await addDoc(collection(db, 'system_dummy'), {}); // Trigger (not needed but for demonstration)
      // Real update
      // await updateDoc(doc(db, 'conversations', activeConversation.id), {
      //   lastMessage: text,
      //   updatedAt: serverTimestamp()
      // });
    } catch (err) {
      console.error(err);
    }
  };

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 py-8 h-[calc(100vh-8rem)]">
      <div className="bg-white rounded-3xl border border-neutral-100 shadow-sm flex h-full overflow-hidden">
        {/* Chat List */}
        <div className={`w-full md:w-80 border-r border-neutral-100 flex flex-col ${activeConversation ? 'hidden md:flex' : 'flex'}`}>
          <div className="p-4 border-b border-neutral-100">
            <h2 className="font-bold text-lg">Messages</h2>
          </div>
          <ScrollArea className="flex-1">
            {loading ? (
              <div className="flex justify-center p-4">
                <Loader2 className="w-5 h-5 animate-spin text-primary" />
              </div>
            ) : conversations.length > 0 ? (
              conversations.map((c) => (
                <div
                  key={c.id}
                  onClick={() => setActiveConversation(c)}
                  className={`p-4 flex items-center gap-3 cursor-pointer hover:bg-neutral-50 transition-colors ${
                    activeConversation?.id === c.id ? 'bg-primary/5 border-r-4 border-primary' : ''
                  }`}
                >
                  <Avatar className="w-12 h-12 rounded-xl">
                    <AvatarImage src={c.otherProfile?.photoUrl} />
                    <AvatarFallback className="bg-neutral-100">{c.otherProfile?.userId?.slice(0, 2) || 'U'}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 overflow-hidden">
                    <h3 className="font-bold text-sm truncate">{c.otherProfile?.userId || 'User'}</h3>
                    <p className="text-xs text-neutral-500 truncate">{c.lastMessage}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-sm text-neutral-400">No conversations yet.</div>
            )}
          </ScrollArea>
        </div>

        {/* Chat Window */}
        <div className={`flex-1 flex flex-col ${!activeConversation ? 'hidden md:flex' : 'flex'}`}>
          {activeConversation ? (
            <>
              <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setActiveConversation(null)}>
                    <ArrowLeft className="w-4 h-4" />
                  </Button>
                  <Avatar className="w-10 h-10 rounded-xl">
                    <AvatarImage src={activeConversation.otherProfile?.photoUrl} />
                    <AvatarFallback>{activeConversation.otherProfile?.userId?.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-bold text-sm">{activeConversation.otherProfile?.userId}</h3>
                    <span className="text-[10px] text-green-500 font-medium">Online</span>
                  </div>
                </div>
              </div>

              <ScrollArea className="flex-1 p-4 bg-neutral-50/30">
                <div className="space-y-4">
                  {messages.map((m) => (
                    <div
                      key={m.id}
                      className={`flex ${m.senderId === user.uid ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[70%] p-3 rounded-2xl text-sm ${
                        m.senderId === user.uid 
                          ? 'bg-primary text-white rounded-tr-none' 
                          : 'bg-white border border-neutral-100 text-neutral-900 rounded-tl-none'
                      }`}>
                        <p>{m.text}</p>
                        <div className={`text-[10px] mt-1 ${m.senderId === user.uid ? 'text-white/60 text-right' : 'text-neutral-400'}`}>
                          {m.createdAt ? format(m.createdAt.toDate(), 'HH:mm') : ''}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              <form onSubmit={handleSendMessage} className="p-4 border-t border-neutral-100 bg-white">
                <div className="flex gap-2">
                  <Input
                    placeholder="Type a respectful message..."
                    className="rounded-xl bg-neutral-50 border-none h-11"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                  />
                  <Button type="submit" size="icon" className="rounded-xl h-11 w-11 bg-primary hover:bg-primary-dark">
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-neutral-400">
              <MessageCircle className="w-12 h-12 mb-4 opacity-20" />
              <p>Select a conversation to start chatting</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessagesPage;
