import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import ProfileCard from '@/components/profile/ProfileCard';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Loader2, Search, SlidersHorizontal } from 'lucide-react';
import { toast } from 'sonner';

const BrowsePage = () => {
  const { user } = useAuth();
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ gender: '', department: '' });

  useEffect(() => {
    const fetchProfiles = async () => {
      if (!user) return;
      setLoading(true);
      try {
        const q = query(
          collection(db, 'profiles'),
          where('uid', '!=', user.uid)
        );
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setProfiles(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchProfiles();
  }, [user]);

  const handleExpressInterest = async (receiverId: string) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'interests'), {
        senderId: user.uid,
        receiverId,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      toast.success("Interest expressed successfully!");
    } catch (err: any) {
      toast.error("Error: " + err.message);
    }
  };

  const filteredProfiles = profiles.filter(p => {
    if (filters.gender && p.gender !== filters.gender) return false;
    if (filters.department && !p.department?.toLowerCase().includes(filters.department.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="container mx-auto px-4 py-8 pb-32">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-6">
        <div>
          <h1 className="text-3xl font-bold">Find Your Match</h1>
          <p className="text-neutral-500">Discover partners who share your values at IIUC.</p>
        </div>
        
        <div className="flex flex-wrap gap-4 w-full md:w-auto">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <Input 
              placeholder="Search department..." 
              className="pl-10 rounded-2xl bg-white border-neutral-100" 
              value={filters.department}
              onChange={(e) => setFilters(prev => ({ ...prev, department: e.target.value }))}
            />
          </div>
          <Select value={filters.gender} onValueChange={(v) => setFilters(prev => ({ ...prev, gender: v }))}>
            <SelectTrigger className="w-[150px] rounded-2xl bg-white border-neutral-100">
              <SelectValue placeholder="Gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Brother</SelectItem>
              <SelectItem value="female">Sister</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="ghost" size="icon" className="rounded-2xl border border-neutral-100 bg-white">
            <SlidersHorizontal className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
        </div>
      ) : filteredProfiles.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProfiles.map((p) => (
            <ProfileCard 
              key={p.id} 
              profile={p} 
              onExpressInterest={handleExpressInterest}
              onView={(id) => console.log('View', id)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-neutral-200">
          <p className="text-neutral-500">No profiles found matching your search.</p>
        </div>
      )}
    </div>
  );
};

export default BrowsePage;
