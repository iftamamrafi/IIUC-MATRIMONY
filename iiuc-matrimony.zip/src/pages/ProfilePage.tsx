import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { doc, updateDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { Loader2, Save, User as UserIcon, Book, Users, Star, Camera } from 'lucide-react';

const ProfilePage = () => {
  const { user, profile: initialProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<any>(initialProfile || {});
  
  useEffect(() => {
    if (initialProfile) {
      setProfile(initialProfile);
    }
  }, [initialProfile]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfile((prev: any) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setProfile((prev: any) => ({ ...prev, [name]: value }));
  };

  const calculateProgress = () => {
    const fields = [
      'fullName', 'gender', 'age', 'department', 'batch', 'height', 
      'maritalStatus', 'religiousPractice', 'prayerRegularity', 'quranReading'
    ];
    const completed = fields.filter(f => !!profile[f]).length;
    return (completed / fields.length) * 100;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    
    try {
      const profileRef = doc(db, 'profiles', user.uid);
      await updateDoc(profileRef, {
        ...profile,
        age: profile.age ? parseInt(profile.age.toString()) : null,
        profileCompleted: calculateProgress() === 100,
        updatedAt: serverTimestamp()
      });
      toast.success("Profile updated successfully!");
    } catch (err: any) {
      toast.error("Error updating profile: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold">Your Profile</h1>
            <p className="text-neutral-500">Complete your profile to find better matches.</p>
          </div>
          <Card className="w-full md:w-64 border-primary/20 shadow-none">
            <CardContent className="p-4">
              <div className="flex justify-between text-sm mb-2">
                <span>Completion</span>
                <span className="font-bold text-primary">{Math.round(calculateProgress())}%</span>
              </div>
              <Progress value={calculateProgress()} className="h-2 bg-primary/10" />
            </CardContent>
          </Card>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Personal Info */}
          <Card className="rounded-3xl border-neutral-100 shadow-sm overflow-hidden">
            <CardHeader className="bg-neutral-50/50 border-b border-neutral-100">
              <div className="flex items-center gap-2">
                <UserIcon className="w-5 h-5 text-primary" />
                <CardTitle className="text-lg">Personal Information</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input id="fullName" name="fullName" value={profile.fullName || ''} onChange={handleChange} className="rounded-xl" placeholder="Full Name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <Select value={profile.gender || ''} onValueChange={(v) => handleSelectChange('gender', v)}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Select Gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input id="age" name="age" type="number" value={profile.age || ''} onChange={handleChange} className="rounded-xl" placeholder="Age" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="height">Height (e.g. 5'7")</Label>
                <Input id="height" name="height" value={profile.height || ''} onChange={handleChange} className="rounded-xl" placeholder="5ft 7in" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="maritalStatus">Marital Status</Label>
                <Select value={profile.maritalStatus || ''} onValueChange={(v) => handleSelectChange('maritalStatus', v)}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Marital Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="never_married">Never Married</SelectItem>
                    <SelectItem value="divorced">Divorced</SelectItem>
                    <SelectItem value="widowed">Widowed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Photo Privacy */}
          <Card className="rounded-3xl border-neutral-100 shadow-sm overflow-hidden">
            <CardHeader className="bg-neutral-50/50 border-b border-neutral-100">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-primary" />
                <CardTitle className="text-lg">Photo Privacy</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="photoPrivacy">Visibility Settings</Label>
                  <Select value={profile.photoPrivacy || 'public'} onValueChange={(v) => handleSelectChange('photoPrivacy', v)}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Public" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">Public (Everyone)</SelectItem>
                      <SelectItem value="interest_accepted">Only after interest accepted</SelectItem>
                      <SelectItem value="hidden">Hidden from everyone</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-xs text-neutral-500 italic">
                  Note: Blurring your photo helps maintain modesty. If restricted, other users will only see a blurred version until conditions are met.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Education & IIUC Info */}
          <Card className="rounded-3xl border-neutral-100 shadow-sm overflow-hidden">
            <CardHeader className="bg-neutral-50/50 border-b border-neutral-100">
              <div className="flex items-center gap-2">
                <Book className="w-5 h-5 text-primary" />
                <CardTitle className="text-lg">IIUC Details</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Input id="department" name="department" value={profile.department || ''} onChange={handleChange} className="rounded-xl" placeholder="e.g. CSE, EEE, Pharmacy" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="batch">Batch / Session</Label>
                <Input id="batch" name="batch" value={profile.batch || ''} onChange={handleChange} className="rounded-xl" placeholder="e.g. 45th, Autumn 2020" />
              </div>
            </CardContent>
          </Card>

          {/* Religious Level */}
          <Card className="rounded-3xl border-neutral-100 shadow-sm overflow-hidden">
            <CardHeader className="bg-neutral-50/50 border-b border-neutral-100">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-primary" />
                <CardTitle className="text-lg">Religious Practice</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Prayer Regularity</Label>
                <Select value={profile.prayerRegularity || ''} onValueChange={(v) => handleSelectChange('prayerRegularity', v)}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Five times daily" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="five_times">Five times</SelectItem>
                    <SelectItem value="most_times">Most of the time</SelectItem>
                    <SelectItem value="sometimes">Sometimes</SelectItem>
                    <SelectItem value="occasional">Occasional</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Quran Reading Ability</Label>
                <Select value={profile.quranReading || ''} onValueChange={(v) => handleSelectChange('quranReading', v)}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Can read with Tajwid" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tajwid">With Tajwid</SelectItem>
                    <SelectItem value="fluent">Fluent</SelectItem>
                    <SelectItem value="learning">Learning</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="familyBackground">Family Background (Brief)</Label>
                <Textarea id="familyBackground" name="familyBackground" value={profile.familyBackground || ''} onChange={handleChange} className="rounded-xl min-h-[100px]" placeholder="Briefly describe your family..." />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end pt-4">
            <Button type="submit" disabled={loading} className="bg-primary hover:bg-primary-dark rounded-xl h-12 px-8 flex items-center gap-2">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Profile
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfilePage;
