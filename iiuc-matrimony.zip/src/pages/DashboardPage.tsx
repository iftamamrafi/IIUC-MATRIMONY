import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button, buttonVariants } from '@/components/ui/button';
import { Heart, Users, MessageCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import ProfileCard from '../components/profile/ProfileCard';
import { cn } from '@/lib/utils';

const DashboardPage = () => {
  const { user, profile } = useAuth();
  const [stats, setStats] = useState({ interests: 0, matches: 0 });
  const [suggestions, setSuggestions] = useState<any[]>([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!user) return;
      
      // Fetch suggestions
      const q = query(
        collection(db, 'profiles'),
        where('uid', '!=', user.uid),
        limit(3)
      );
      const snapshot = await getDocs(q);
      setSuggestions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      
      // Fetch interest count
      const iq = query(collection(db, 'interests'), where('receiverId', '==', user.uid));
      const iSnapshot = await getDocs(iq);
      setStats(prev => ({ ...prev, interests: iSnapshot.size }));
    };

    fetchDashboardData();
  }, [user]);

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 py-8 pb-32">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Assalamu Alaikum, {profile?.fullName || 'Brother/Sister'}</h1>
        <p className="text-neutral-500">Welcome to your dashboard. Here's what's happening.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card className="rounded-3xl border-neutral-100 shadow-sm bg-primary text-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <Heart className="w-8 h-8 opacity-50" />
              <Badge className="bg-white/20 text-white border-none">New</Badge>
            </div>
            <div className="text-3xl font-bold mb-1">{stats.interests}</div>
            <div className="text-sm opacity-80 uppercase tracking-wider font-semibold">New Interests</div>
          </CardContent>
        </Card>
        
        <Card className="rounded-3xl border-neutral-100 shadow-sm bg-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4 text-primary">
              <MessageCircle className="w-8 h-8 opacity-50" />
            </div>
            <div className="text-3xl font-bold mb-1">{stats.matches}</div>
            <div className="text-sm text-neutral-500 uppercase tracking-wider font-semibold">Active Chats</div>
          </CardContent>
        </Card>

        <Card className="rounded-3xl border-neutral-100 shadow-sm bg-white">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4 text-accent">
              <ShieldCheck className="w-8 h-8 opacity-50" />
            </div>
            <div className="text-lg font-bold mb-1">{profile?.isVerified ? 'Verified Account' : 'Verification Pending'}</div>
            <div className="text-sm text-neutral-500">{profile?.isVerified ? 'You are a trusted member.' : 'Complete your profile for badge.'}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">Suggested Profiles</h2>
            <Link to="/browse" className="text-primary text-sm font-semibold flex items-center gap-1 hover:underline">
              See All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {suggestions.map(p => (
              <ProfileCard 
                key={p.id} 
                profile={p} 
                onExpressInterest={() => {}} 
                onView={() => {}} 
              />
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold mb-6">Profile Completion</h2>
          <Card className="rounded-3xl border-neutral-100 shadow-sm bg-white">
            <CardContent className="p-6 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Profile Score</span>
                <span className="text-primary font-bold">85%</span>
              </div>
              <div className="h-2 w-full bg-neutral-100 rounded-full overflow-hidden">
                <div className="h-full bg-primary" style={{ width: '85%' }} />
              </div>
              <p className="text-xs text-neutral-500">Adding a detailed family background increases your trust score by 15%.</p>
              <Link 
                to="/profile" 
                className={cn(
                  buttonVariants({ variant: 'ghost' }), 
                  "w-full rounded-2xl bg-neutral-100 text-neutral-900 border-none hover:bg-neutral-200 flex items-center justify-center"
                )}
              >
                Complete Profile
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

const Badge = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${className}`}>
    {children}
  </span>
);

export default DashboardPage;
